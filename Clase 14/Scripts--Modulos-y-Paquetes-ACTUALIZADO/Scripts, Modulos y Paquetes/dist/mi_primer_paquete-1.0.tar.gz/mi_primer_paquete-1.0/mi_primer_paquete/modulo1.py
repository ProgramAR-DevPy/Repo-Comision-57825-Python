def saludar(nombre):
    print(f"¡Hola, {nombre}!")