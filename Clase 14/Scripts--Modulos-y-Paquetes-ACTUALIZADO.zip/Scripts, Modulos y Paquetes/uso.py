#import funciones_matematicas

#from funciones_matematicas import suma

from funciones_matematicas import *
