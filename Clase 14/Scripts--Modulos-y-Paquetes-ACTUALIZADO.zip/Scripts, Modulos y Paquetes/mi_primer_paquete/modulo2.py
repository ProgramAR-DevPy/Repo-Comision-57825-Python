# modulo2.py
def despedirse(nombre):
    print(f"¡Adiós, {nombre}!")