# funciones_matematicas.py

def suma(a, b):
    """Suma dos números y devuelve el resultado."""
    return a + b

def resta(a, b):
    """Resta dos números y devuelve el resultado."""
    return a - b