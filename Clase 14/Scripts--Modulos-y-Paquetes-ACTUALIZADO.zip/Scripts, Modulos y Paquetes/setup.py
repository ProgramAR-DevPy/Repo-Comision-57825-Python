from setuptools import setup

setup (

    name="mi_primer_paquete",
    version= "1.0",
    description= "Estamos haciendo el primer paquete",
    author= "Ale de la 57825",
    author_email= "Ale Sosa",

    packages=["mi_primer_paquete"]

)