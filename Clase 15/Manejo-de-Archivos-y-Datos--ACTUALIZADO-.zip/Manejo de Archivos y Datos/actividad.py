def guardar_hobbies():
    """Pide al usuario sus hobbies favoritos y los guarda en un archivo de texto."""

    hobbies = []  # Lista para almacenar los hobbies
    num_hobbies = 3

    for i in range(num_hobbies):
        hobbie = input(f"Ingresa tu hobbie favorito número {i + 1}: ")
        hobbies.append(hobbie)  # Agregamos el hobbie a la lista

    # Guardamos los hobbies en el archivo
    with open("miHobbieFavorito.txt", "w") as archivo:
        for hobbie in hobbies:
            archivo.write(hobbie + "\n")  # Escribimos cada hobbie en una línea nueva

    print("Tus hobbies favoritos se han guardado en miHobbieFavorito.txt")

# Llamamos a la función para ejecutar el programa
guardar_hobbies()
