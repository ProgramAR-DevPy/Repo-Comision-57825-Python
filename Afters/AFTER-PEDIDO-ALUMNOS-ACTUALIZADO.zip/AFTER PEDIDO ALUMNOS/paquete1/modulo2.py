#Aca tenemos que pegar el codigo que hicimos en colab de la pre entrega 1

