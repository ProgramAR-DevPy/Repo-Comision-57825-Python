#1. Importar los modulos

#2. Instanciar un objeto

#3.Darle acciones al objeto
       
#4. Podemos manejar todo lo anterior con un menu




        


