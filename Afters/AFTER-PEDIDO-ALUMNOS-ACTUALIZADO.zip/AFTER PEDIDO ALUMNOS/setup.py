from setuptools import setup


setup (
    name="paquete1",
    version= "1.0",
    description="Paquete de segunda pre entrega",
    author="Alumnos After class",
    author_email= "prueba@coder.com",

    packages= ["paquete1"]

)

