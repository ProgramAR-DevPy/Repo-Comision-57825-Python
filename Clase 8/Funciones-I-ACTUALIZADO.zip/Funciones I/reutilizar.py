# # #Pero como es eso de reutlizar una función?
# # #Completamos en clase

# # def funcion():
# #     pass


# # def saludar(nombre):
# #     """dsfsdfsd"""
# #     #print(f"hola {nombre} ")
# #     return nombre




# # saludar("Alejandro")


# # def enviar_carta(direccion):  # "direccion" y "contenido" son parámetros
# #     print(f"Enviando carta a: {direccion}")
# #     #print(f"Contenido de la carta: {cadena}")

# # enviar_carta("123 Calle Falsa", 1)  # "123 Calle Falsa" y "Hola, ¿cómo estás?" son argumentos


# # def sumar(a, b):
# #     resultado = a + b
    
# #     return resultado
    

# # suma = sumar(5, 3)
# # print(suma)  


# # def mi_funcion():
# #     x = 10  # Variable local "x"
# #     print(x)  # Output: 10

# # mi_funcion()




# # def test():
# #     variable_test = 10
# #     print(variable_test)

# # test()


# def suma(numero1, numero2):
#     return numero1 - numero2


# print(suma(15, 5))


# def suma1(a = 20, b = 5):
#     return a + b


# operacion = 150

# nueva_variable = suma1() + operacion

# print(nueva_variable)


def mi_funcion():
    print("imprimo 1")
    print("imprimo 2")
    print("imprimo 3")
    print("imprimo 4")
    print("imprimo 5")
    print("imprimo 6")

    return 5
    print("¡Adiós!")  

resultado = mi_funcion()
print(resultado)  # Output: 5