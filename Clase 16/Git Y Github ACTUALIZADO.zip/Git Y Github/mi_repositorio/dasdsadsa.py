print("hola mundo")
print("chanchito feliz")
print("Ahora yo soy el crack")
